// RESOURCE MANAGEMENT (RM) request.js - FIXED

import { supabase } from "../../supabaseClient.js";

function debounce(func, delay = 300) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

// ============================================
// MODAL UTILITIES
// ============================================

class ModalManager {
    static show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    static showLoading() {
        this.show('loadingOverlay');
    }

    static hideLoading() {
        this.hide('loadingOverlay');
    }
}

// ============================================
// MESSAGE UTILITIES
// ============================================

class MessageManager {
    static show(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        if (!container) return;

        const messageBox = document.createElement('div');
        messageBox.className = `message-box ${type}`;

        const iconMap = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const icon = document.createElement('i');
        icon.className = `fas ${iconMap[type]}`;

        const text = document.createElement('span');
        text.textContent = message;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'message-close';
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.addEventListener('click', () => messageBox.remove());

        messageBox.appendChild(icon);
        messageBox.appendChild(text);
        messageBox.appendChild(closeBtn);

        container.appendChild(messageBox);

        setTimeout(() => {
            messageBox.remove();
        }, 5000);
    }

    static success(message) {
        this.show(message, 'success');
    }

    static error(message) {
        this.show(message, 'error');
    }

    static warning(message) {
        this.show(message, 'warning');
    }

    static info(message) {
        this.show(message, 'info');
    }
}

// ============================================
// DATA SERVICE (Supabase Connected)
// ============================================

class DataService {
    constructor() {
        this.currentUser = this.getCurrentUser();
    }

    getCurrentUser() {
        const user = localStorage.getItem("loggedUser");
        const parsedUser = user ? JSON.parse(user) : null;
        console.log('Current user from localStorage:', parsedUser);
        return parsedUser;
    }

    async getAllRequests() {
        try {
            const { data, error } = await supabase
                .from('resource_requests')
                .select(`
                    *,
                    project:projects(
                        id,
                        name,
                        description,
                        priority
                    ),
                    requirement:project_requirements(
                        id,
                        experience_level,
                        quantity_needed,
                        required_skills
                    ),
                    requester:users!resource_requests_requested_by_fkey(
                        id,
                        name,
                        email
                    ),
                    approver:users!resource_requests_approved_by_fkey(
                        id,
                        name
                    )
                `)
                .order('requested_at', { ascending: false });

            if (error) throw error;

            // Transform data to match UI expectations
            return data.map(req => {
                const skills = req.requirement?.required_skills || [];
                const quantity = req.requirement?.quantity_needed || 1;
                
                return {
                    id: `REQ${String(req.id).padStart(3, '0')}`,
                    rawId: req.id,
                    projectName: req.project?.name || 'N/A',
                    projectId: req.project?.id,
                    projectDescription: req.project?.description || 'No description available',
                    requester: req.requester?.name || 'N/A',
                    requesterEmail: req.requester?.email || 'N/A',
                    department: 'N/A',
                    position: 'Developer',
                    skillsRequired: skills,
                    allSkills: skills,
                    experience: this.formatExperienceLevel(req.requirement?.experience_level),
                    experienceLevel: req.requirement?.experience_level,
                    quantity: quantity,
                    totalResources: quantity,
                    priority: this.capitalize(req.project?.priority || 'medium'),
                    startDate: req.start_date || null,
                    endDate: req.end_date || null,
                    duration: this.formatDuration(req.duration_days),
                    durationDays: req.duration_days || 0,
                    status: req.status,
                    submittedDate: req.requested_at,
                    notes: req.notes,
                    approvedBy: req.approver?.name,
                    approvedAt: req.approved_at
                };
            });
        } catch (error) {
            console.error('Error fetching requests:', error);
            throw error;
        }
    }

    async getRequestById(id) {
        try {
            // Extract raw ID from formatted ID (REQ001 -> 1)
            const rawId = typeof id === 'string' && id.startsWith('REQ') 
                ? parseInt(id.replace('REQ', '')) 
                : id;

            const { data, error } = await supabase
                .from('resource_requests')
                .select(`
                    *,
                    project:projects(
                        id,
                        name,
                        description,
                        priority
                    ),
                    requirement:project_requirements(
                        id,
                        experience_level,
                        quantity_needed,
                        required_skills
                    ),
                    requester:users!resource_requests_requested_by_fkey(
                        id,
                        name,
                        email
                    ),
                    approver:users!resource_requests_approved_by_fkey(
                        id,
                        name
                    )
                `)
                .eq('id', rawId)
                .single();

            if (error) throw error;

            const skills = data.requirement?.required_skills || [];
            const quantity = data.requirement?.quantity_needed || 1;

            return {
                id: `REQ${String(data.id).padStart(3, '0')}`,
                rawId: data.id,
                projectName: data.project?.name || 'N/A',
                projectId: data.project?.id,
                projectDescription: data.project?.description || 'No description available',
                requester: data.requester?.name || 'N/A',
                requesterEmail: data.requester?.email || 'N/A',
                department: 'N/A',
                position: 'Developer',
                skillsRequired: skills,
                allSkills: skills,
                experience: this.formatExperienceLevel(data.requirement?.experience_level),
                experienceLevel: data.requirement?.experience_level,
                quantity: quantity,
                totalResources: quantity,
                priority: this.capitalize(data.project?.priority || 'medium'),
                startDate: data.start_date || null,
                endDate: data.end_date || null,
                duration: this.formatDuration(data.duration_days),
                durationDays: data.duration_days || 0,
                status: data.status,
                submittedDate: data.requested_at,
                notes: data.notes,
                approvedBy: data.approver?.name,
                approvedAt: data.approved_at
            };
        } catch (error) {
            console.error('Error fetching request:', error);
            throw error;
        }
    }

    async updateRequestStatus(id, status, notes = null) {
        try {
            // Extract raw ID
            const rawId = typeof id === 'string' && id.startsWith('REQ') 
                ? parseInt(id.replace('REQ', '')) 
                : id;

            console.log('Updating request - Input ID:', id, 'Raw ID:', rawId, 'Status:', status);

            const updateData = {
                status: status,
                approved_by: this.currentUser?.id,
                approved_at: new Date().toISOString()
            };

            if (notes) {
                updateData.notes = notes;
            }

            console.log('Update data:', updateData);

            // First, get the project_id from the request
            const { data: existingRequest, error: fetchError } = await supabase
                .from('resource_requests')
                .select('project_id, id, status')
                .eq('id', rawId)
                .single();

            console.log('Existing request:', existingRequest, 'Fetch error:', fetchError);

            if (fetchError) throw fetchError;

            // Update resource request status
            const { data: requestData, error: requestError } = await supabase
                .from('resource_requests')
                .update(updateData)
                .eq('id', rawId)
                .select();

            console.log('Update result:', requestData, 'Update error:', requestError);

            if (requestError) throw requestError;

            // If approved, update project status to 'ongoing'
            if (status === 'approved' && existingRequest?.project_id) {
                console.log('Updating project status for project ID:', existingRequest.project_id);
                
                const { error: projectError } = await supabase
                    .from('projects')
                    .update({ status: 'ongoing' })
                    .eq('id', existingRequest.project_id);

                if (projectError) {
                    console.error('Error updating project status:', projectError);
                    // Don't throw - request was still approved
                }
            }

            return { success: true, data: requestData };
        } catch (error) {
            console.error('Error updating request status:', error);
            throw error;
        }
    }

    formatExperienceLevel(level) {
        const map = {
            'beginner': 'Beginner',
            'intermediate': 'Intermediate',
            'advanced': 'Advanced'
        };
        return map[level] || level;
    }

    formatDuration(durationDays) {
        if (!durationDays || durationDays === 0) return 'N/A';
        
        if (durationDays < 30) {
            return `${durationDays} days`;
        } else {
            const months = Math.round(durationDays / 30);
            return `${months} month${months > 1 ? 's' : ''}`;
        }
    }

    capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

// ============================================
// UI MANAGER
// ============================================

class UIManager {
    constructor() {}

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    }

    capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    getPriorityColor(priority) {
        const colors = {
            High: '#D0021B',
            Medium: '#F5A623',
            Low: '#4A90E2'
        };
        return colors[priority] || '#6C757D';
    }

    renderRequests(requests) {
        const container = document.getElementById('requestsList');
        
        if (!container) return;

        if (requests.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #6C757D; padding: 40px;">No requests found</p>';
            return;
        }

        const fragment = document.createDocumentFragment();

        requests.forEach(req => {
            const card = this.createRequestCard(req);
            fragment.appendChild(card);
        });

        container.innerHTML = '';
        container.appendChild(fragment);
    }

    createRequestCard(req) {
        const card = document.createElement('div');
        card.className = 'request-card';
        card.dataset.id = req.id;
        card.dataset.rawId = req.rawId;

        card.innerHTML = document.getElementById('requestCardTemplate').innerHTML;
        this.populateRequestCard(card, req);

        return card;
    }

    populateRequestCard(card, req) {
        const statusClass = req.status.toLowerCase();
        const statusDisplay = this.capitalize(req.status);

        card.querySelector('.request-project-name').textContent = req.projectName;
        card.querySelector('.meta-project').textContent = req.projectName;
        card.querySelector('.meta-requester').textContent = req.requester;
        card.querySelector('.meta-date').textContent = this.formatDate(req.submittedDate);
        card.querySelector('.meta-resources').textContent = `${req.totalResources} Resource${req.totalResources !== 1 ? 's' : ''}`;

        const statusElem = card.querySelector('.request-status');
        statusElem.textContent = statusDisplay;
        statusElem.className = `request-status ${statusClass}`;

        const skillsContainer = card.querySelector('.skills-tags');
        skillsContainer.innerHTML = '';
        req.allSkills.slice(0, 3).forEach(skill => {
            const tag = document.createElement('span');
            tag.className = 'skill-tag';
            tag.textContent = skill;
            skillsContainer.appendChild(tag);
        });
        if (req.allSkills.length > 3) {
            const more = document.createElement('span');
            more.className = 'skill-tag-more';
            more.textContent = `+${req.allSkills.length - 3} more`;
            skillsContainer.appendChild(more);
        }

        card.querySelector('.timeline-value').textContent = `${this.formatDate(req.startDate)} - ${this.formatDate(req.endDate)}`;
        card.querySelector('.duration-value').textContent = `${req.durationDays} days`;
        card.querySelector('.start-date-value').textContent = this.formatDate(req.startDate);
        card.querySelector('.end-date-value').textContent = this.formatDate(req.endDate);

        // Set up action buttons
        const viewBtn = card.querySelector('.btn-view');
        viewBtn.onclick = () => window.requestController.viewRequest(req.id);

        const approveBtn = card.querySelector('.btn-approve');
        const rejectBtn = card.querySelector('.btn-reject');

        if (req.status === 'pending') {
            approveBtn.style.display = '';
            rejectBtn.style.display = '';
            approveBtn.onclick = () => window.requestController.openApproveModal(req.id);
            rejectBtn.onclick = () => window.requestController.openRejectModal(req.id);
        } else {
            approveBtn.style.display = 'none';
            rejectBtn.style.display = 'none';
        }
    }
}

// ============================================
// REQUEST CONTROLLER
// ============================================

class RequestController {
    constructor() {
        this.dataService = new DataService();
        this.uiManager = new UIManager();
        this.currentRequestId = null;
        this.currentFilter = '';
    }

    async initialize() {
        // Check if user is logged in
        if (!this.dataService.currentUser) {
            window.location.href = '../index.html';
            return;
        }

        // Check if user is resource manager
        if (this.dataService.currentUser.role !== 'resource_manager') {
            MessageManager.error('Access denied. Resource Manager role required.');
            setTimeout(() => {
                window.location.href = '../index.html';
            }, 2000);
            return;
        }

        this.setupEventListeners();
        await this.loadRequests();
    }

    async loadRequests(filter = '') {
        try {
            ModalManager.showLoading();
            let requests = await this.dataService.getAllRequests();

            // Only show approved requests if explicitly filtered
            if (filter === '') {
                // Default view: Show only pending and rejected (NOT approved)
                requests = requests.filter(req => req.status !== 'approved');
            } else if (filter) {
                requests = requests.filter(req => req.status === filter);
            }

            this.uiManager.renderRequests(requests);
        } catch (error) {
            MessageManager.error('Failed to load requests');
            console.error(error);
        } finally {
            ModalManager.hideLoading();
        }
    }

    async viewRequest(id) {
    try {
        ModalManager.showLoading();
        const request = await this.dataService.getRequestById(id);
        
        if (!request) {
            MessageManager.error('Request not found');
            return;
        }

        // Populate modal with request details
        document.getElementById('detailProjectName').textContent = request.projectName;
        document.getElementById('detailProjectDesc').textContent = request.projectDescription;
        
        const statusElem = document.getElementById('detailStatus');
        statusElem.textContent = this.capitalize(request.status);
        statusElem.className = `request-status ${request.status.toLowerCase()}`;
        
        document.getElementById('detailSubmitted').textContent = this.uiManager.formatDate(request.submittedDate);
        
        // Show/hide approved row
        const approvedRow = document.getElementById('detailApprovedRow');
        if (request.approvedAt) {
            approvedRow.style.display = '';
            document.getElementById('detailApproved').textContent = this.uiManager.formatDate(request.approvedAt);
        } else {
            approvedRow.style.display = 'none';
        }
        
        // Timeline dates
        document.getElementById('detailStartDate').textContent = this.uiManager.formatDate(request.startDate);
        document.getElementById('detailEndDate').textContent = this.uiManager.formatDate(request.endDate);
        document.getElementById('detailDuration').textContent = `${request.durationDays} days`;
        
        // Populate Requirements Table
        const tbody = document.getElementById('requirementsTableBody');
        tbody.innerHTML = '';
        
        // Create table row with request data
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${request.quantity || 1}</td>
            <td>${this.capitalize(request.experienceLevel || 'N/A')}</td>
            <td>${request.assignmentType || 'Full-Time'}</td>
            <td>
                <div class="skills-tags">
                    ${request.allSkills.map(skill => 
                        `<span class="skill-tag">${skill}</span>`
                    ).join('')}
                </div>
            </td>
        `;
        tbody.appendChild(row);
        
        document.getElementById('detailNotes').textContent = request.notes || 'No additional notes';
        
        ModalManager.hideLoading();
        ModalManager.show('requestDetailModal');
    } catch (error) {
        ModalManager.hideLoading();
        MessageManager.error('Failed to load request details');
        console.error(error);
    }
}

    capitalize(str) {
        if (!str) return '';
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    openApproveModal(id) {
        this.currentRequestId = id;
        ModalManager.show('approveRequestModal');
    }

    openRejectModal(id) {
        this.currentRequestId = id;
        document.getElementById('rejectReason').value = '';
        ModalManager.show('rejectRequestModal');
    }

    async approveRequest() {
        if (!this.currentRequestId) return;

        try {
            ModalManager.hide('approveRequestModal');
            ModalManager.showLoading();

            console.log('Approving request ID:', this.currentRequestId);
            
            const result = await this.dataService.updateRequestStatus(this.currentRequestId, 'approved');
            
            console.log('Approval result:', result);
            
            MessageManager.success('Request approved successfully. Project moved to Projects page.');
            await this.loadRequests(this.currentFilter);
            this.currentRequestId = null;
        } catch (error) {
            MessageManager.error('Failed to approve request: ' + error.message);
            console.error('Approval error:', error);
        } finally {
            ModalManager.hideLoading();
        }
    }

    async rejectRequest() {
        if (!this.currentRequestId) return;

        const reason = document.getElementById('rejectReason').value.trim();

        try {
            ModalManager.hide('rejectRequestModal');
            ModalManager.showLoading();

            await this.dataService.updateRequestStatus(this.currentRequestId, 'rejected', reason);
            
            MessageManager.success('Request rejected');
            await this.loadRequests(this.currentFilter);
            this.currentRequestId = null;
        } catch (error) {
            MessageManager.error('Failed to reject request');
            console.error(error);
        } finally {
            ModalManager.hideLoading();
        }
    }

    handleLogout() {
        ModalManager.show('logoutModal');
    }

    async confirmLogout() {
        ModalManager.hide('logoutModal');
        ModalManager.showLoading();
        
        localStorage.removeItem('loggedUser');
        
        setTimeout(() => {
            ModalManager.hideLoading();
            MessageManager.success('Logged out successfully');
            window.location.href = '/login/HTML_Files/login.html';
        }, 1000);
    }

    setupEventListeners() {
        // Filter
        const filterSelect = document.getElementById('requestStatusFilter');
        if (filterSelect) {
            filterSelect.addEventListener('change', (e) => {
                this.currentFilter = e.target.value;
                this.loadRequests(this.currentFilter);
            });
        }

        // Detail Modal
        const closeDetailBtn = document.getElementById('closeDetailModal');
        const closeDetailBtnAlt = document.getElementById('closeDetailBtn');
        if (closeDetailBtn) {
            closeDetailBtn.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        }
        if (closeDetailBtnAlt) {
            closeDetailBtnAlt.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        }

        // Approve Modal
        const cancelApproveBtn = document.getElementById('cancelApprove');
        const confirmApproveBtn = document.getElementById('confirmApprove');
        if (cancelApproveBtn) {
            cancelApproveBtn.addEventListener('click', () => {
                ModalManager.hide('approveRequestModal');
                this.currentRequestId = null;
            });
        }
        if (confirmApproveBtn) {
            confirmApproveBtn.addEventListener('click', () => this.approveRequest());
        }

        // Reject Modal
        const cancelRejectBtn = document.getElementById('cancelReject');
        const confirmRejectBtn = document.getElementById('confirmReject');
        if (cancelRejectBtn) {
            cancelRejectBtn.addEventListener('click', () => {
                ModalManager.hide('rejectRequestModal');
                this.currentRequestId = null;
            });
        }
        if (confirmRejectBtn) {
            confirmRejectBtn.addEventListener('click', () => this.rejectRequest());
        }

        // Logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        const cancelLogoutBtn = document.getElementById('cancelLogout');
        const confirmLogoutBtn = document.getElementById('confirmLogout');
        if (cancelLogoutBtn) {
            cancelLogoutBtn.addEventListener('click', () => ModalManager.hide('logoutModal'));
        }
        if (confirmLogoutBtn) {
            confirmLogoutBtn.addEventListener('click', () => this.confirmLogout());
        }

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
    }
}

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    const controller = new RequestController();
    window.requestController = controller;
    controller.initialize();
});