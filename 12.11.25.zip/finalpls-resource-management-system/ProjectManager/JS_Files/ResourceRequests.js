// PROJECT MANAGER (PM) Resource Requests.js - PM View (Create & Track Requests)
import { supabase } from "../../supabaseClient.js";

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatStatus(status) {
    return status.split('-').map(word => capitalize(word)).join(' ');
}

function calculateDurationDays(startDate, endDate) {
    if (!startDate || !endDate) return 0;
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// ============================================
// MODAL MANAGER
// ============================================

class ModalManager {
    static show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    static showLoading() {
        this.show('loadingOverlay');
    }

    static hideLoading() {
        this.hide('loadingOverlay');
    }
}

// ============================================
// MESSAGE MANAGER
// ============================================

class MessageManager {
    static show(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        if (!container) return;

        const messageBox = document.createElement('div');
        messageBox.className = `message-box ${type}`;

        const iconMap = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const icon = document.createElement('i');
        icon.className = `fas ${iconMap[type]}`;

        const text = document.createElement('span');
        text.textContent = message;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'message-close';
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.addEventListener('click', () => messageBox.remove());

        messageBox.appendChild(icon);
        messageBox.appendChild(text);
        messageBox.appendChild(closeBtn);

        container.appendChild(messageBox);

        setTimeout(() => messageBox.remove(), 5000);
    }

    static success(message) { this.show(message, 'success'); }
    static error(message) { this.show(message, 'error'); }
    static warning(message) { this.show(message, 'warning'); }
    static info(message) { this.show(message, 'info'); }
}

// ============================================
// PM DATA SERVICE
// ============================================

class PMDataService {
    constructor() {
        this.currentPMId = null;
        this.currentPMEmail = null;
    }

    async initialize() {
        const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
        
        if (!loggedUser.email) {
            throw new Error('No logged in user found');
        }

        this.currentPMEmail = loggedUser.email;
        
        const { data: userData, error } = await supabase
            .from('users')
            .select('id, name, email, role')
            .eq('email', this.currentPMEmail)
            .eq('role', 'project_manager')
            .single();

        if (error) {
            console.error('[PM DATA SERVICE] Error fetching PM user:', error);
            throw error;
        }

        this.currentPMId = userData.id;
        console.log('[PM DATA SERVICE] Initialized for PM:', userData);
    }

    async getMyProjects() {
        try {
            const { data: projects, error } = await supabase
                .from('projects')
                .select('id, name, status')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active', 'on-hold'])
                .order('created_at', { ascending: false });

            if (error) throw error;
            return projects || [];
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching projects:', error);
            return [];
        }
    }

    async getMyRequests() {
        try {
            console.log('[PM DATA SERVICE] Fetching requests for PM:', this.currentPMId);

            // First, get all projects created by this PM
            const { data: myProjects, error: projectError } = await supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId);

            if (projectError) throw projectError;

            const myProjectIds = myProjects?.map(p => p.id) || [];
            
            if (myProjectIds.length === 0) {
                console.log('[PM DATA SERVICE] No projects found for this PM');
                return [];
            }

            // Then, get only requests for those projects
            const { data: requests, error } = await supabase
                .from('resource_requests')
                .select(`
                    id,
                    project_id,
                    requested_at,
                    approved_at,
                    approved_by,
                    status,
                    notes,
                    start_date,
                    end_date,
                    duration_days,
                    projects!inner (
                        name,
                        description,
                        created_by
                    )
                `)
                .in('project_id', myProjectIds)
                .order('requested_at', { ascending: false });

            if (error) throw error;

            console.log('[PM DATA SERVICE] Requests fetched:', requests?.length || 0);

            const requestsWithRequirements = await Promise.all(
                (requests || []).map(async (req) => {
                    const { data: requirements, error: reqError } = await supabase
                        .from('project_requirements')
                        .select('*')
                        .eq('project_id', req.project_id);

                    if (reqError) {
                        console.error('Error fetching requirements:', reqError);
                        return null;
                    }

                    const totalResources = requirements.reduce((sum, r) => sum + (r.quantity_needed || 0), 0);
                    const allSkills = [...new Set(requirements.flatMap(r => r.required_skills || []))];

                    return {
                        id: `REQ${String(req.id).padStart(3, '0')}`,
                        rawId: req.id,
                        project: req.projects?.name || 'Unknown Project',
                        projectId: req.project_id,
                        projectDescription: req.projects?.description || '',
                        requirements: requirements,
                        totalResources: totalResources,
                        allSkills: allSkills,
                        startDate: req.start_date || '',
                        endDate: req.end_date || '',
                        durationDays: req.duration_days || 0,
                        status: req.status,
                        submittedDate: req.requested_at || '',
                        approvedAt: req.approved_at || '',
                        notes: req.notes || ''
                    };
                })
            );

            return requestsWithRequirements.filter(r => r !== null);
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching requests:', error);
            return [];
        }
    }

    async submitRequest(requestData) {
        try {
            const projectId = parseInt(requestData.project);
            
            for (const resource of requestData.resources) {
                const durationDays = calculateDurationDays(resource.startDate, resource.endDate);
                
                const requirementData = {
                    project_id: projectId,
                    experience_level: resource.skillLevel,
                    quantity_needed: parseInt(resource.quantity) || 1,
                    required_skills: resource.skills,
                    preferred_assignment_type: resource.assignmentType
                };

                const { data: requirement, error: reqError } = await supabase
                    .from('project_requirements')
                    .insert(requirementData)
                    .select()
                    .single();

                if (reqError) throw reqError;

                const resourceRequestData = {
                    project_id: projectId,
                    requirement_id: requirement.id,
                    requested_by: this.currentPMId,
                    status: 'pending',
                    notes: resource.justification || `Requesting ${resource.position} with skills: ${resource.skills.join(', ')}`,
                    start_date: resource.startDate,
                    end_date: resource.endDate,
                    duration_days: durationDays
                };

                const { error: requestError } = await supabase
                    .from('resource_requests')
                    .insert(resourceRequestData);

                if (requestError) throw requestError;
            }

            return { 
                success: true, 
                message: 'Resource request submitted successfully'
            };
        } catch (error) {
            console.error('[PM DATA SERVICE] Error submitting request:', error);
            throw error;
        }
    }

    async getRequestDetails(requestId) {
        try {
            const numericId = parseInt(requestId.replace('REQ', ''));

            const { data: request, error } = await supabase
                .from('resource_requests')
                .select(`
                    *,
                    projects (
                        name,
                        description,
                        start_date,
                        end_date
                    )
                `)
                .eq('id', numericId)
                .single();

            if (error) throw error;

            const { data: requirements, error: reqError } = await supabase
                .from('project_requirements')
                .select('*')
                .eq('project_id', request.project_id);

            if (reqError) throw reqError;

            return {
                ...request,
                requirements: requirements || []
            };
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching request details:', error);
            throw error;
        }
    }
}

// ============================================
// RESOURCE ROW MANAGER
// ============================================

class ResourceRowManager {
    constructor() {
        this.rowCounter = 0;
        this.container = null;
        this.template = null;
    }

    init(containerId) {
        this.container = document.getElementById(containerId);
        this.template = document.getElementById('resourceRowTemplate');
        if (this.container) {
            this.addResourceRow();
        }
    }

    addResourceRow() {
        if (!this.container || !this.template) return;

        this.rowCounter++;
        const rowId = `resource-row-${this.rowCounter}`;

        const rowElement = document.createElement('div');
        rowElement.className = 'resource-row';
        rowElement.id = rowId;
        rowElement.dataset.rowId = this.rowCounter;
        rowElement.innerHTML = this.template.innerHTML;

        // Update IDs and labels
        rowElement.querySelector('.resource-row-title').textContent = `Resource #${this.rowCounter}`;
        
        const inputs = rowElement.querySelectorAll('[id]');
        inputs.forEach(input => {
            const oldId = input.id;
            input.id = `${oldId}-${this.rowCounter}`;
        });

        const labels = rowElement.querySelectorAll('label[for]');
        labels.forEach(label => {
            const oldFor = label.getAttribute('for');
            label.setAttribute('for', `${oldFor}-${this.rowCounter}`);
        });

        this.container.appendChild(rowElement);

        const today = new Date().toISOString().split('T')[0];
        const startDateInput = rowElement.querySelector('.resource-start-date');
        const endDateInput = rowElement.querySelector('.resource-end-date');
        if (startDateInput) startDateInput.min = today;
        if (endDateInput) endDateInput.min = today;

        if (this.rowCounter > 1) {
            const removeBtn = rowElement.querySelector('.btn-remove-resource');
            if (removeBtn) {
                removeBtn.style.display = '';
                removeBtn.addEventListener('click', () => this.removeResourceRow(this.rowCounter));
            }
        } else {
            const removeBtn = rowElement.querySelector('.btn-remove-resource');
            if (removeBtn) removeBtn.style.display = 'none';
        }

        this.updateRowNumbers();
    }

    removeResourceRow(rowId) {
        const row = document.getElementById(`resource-row-${rowId}`);
        if (row) {
            row.remove();
            this.updateRowNumbers();
        }
    }

    updateRowNumbers() {
        const rows = this.container.querySelectorAll('.resource-row');
        rows.forEach((row, index) => {
            const title = row.querySelector('.resource-row-title');
            if (title) {
                title.textContent = `Resource #${index + 1}`;
            }
        });
    }

    getResourcesData() {
        const rows = this.container.querySelectorAll('.resource-row');
        const resources = [];

        rows.forEach((row) => {
            const resource = {
                position: row.querySelector('.resource-position')?.value || '',
                quantity: row.querySelector('.resource-quantity')?.value || '1',
                skillLevel: row.querySelector('.resource-skill-level')?.value || '',
                assignmentType: row.querySelector('.resource-assignment-type')?.value || '',
                skills: (row.querySelector('.resource-skills')?.value || '').split(',').map(s => s.trim()).filter(s => s),
                startDate: row.querySelector('.resource-start-date')?.value || '',
                endDate: row.querySelector('.resource-end-date')?.value || '',
                justification: row.querySelector('.resource-justification')?.value || ''
            };

            resources.push(resource);
        });

        return resources;
    }

    reset() {
        this.container.innerHTML = '';
        this.rowCounter = 0;
        this.addResourceRow();
    }
}

// ============================================
// UI MANAGER
// ============================================

class UIManager {
    populateRequestCard(card, request) {
        const statusClass = request.status.toLowerCase();
        const statusDisplay = formatStatus(request.status);

        card.querySelector('.request-project-name').textContent = request.project;
        card.querySelector('.meta-project').textContent = request.project;
        card.querySelector('.meta-date').textContent = formatDate(request.submittedDate);
        card.querySelector('.meta-resources').textContent = `${request.totalResources} Resource${request.totalResources !== 1 ? 's' : ''}`;

        const statusElem = card.querySelector('.request-status');
        statusElem.textContent = statusDisplay;
        statusElem.className = `request-status ${statusClass}`;

        const skillsContainer = card.querySelector('.skills-tags');
        skillsContainer.innerHTML = '';
        request.allSkills.slice(0, 3).forEach(skill => {
            const tag = document.createElement('span');
            tag.className = 'skill-tag';
            tag.textContent = skill;
            skillsContainer.appendChild(tag);
        });
        if (request.allSkills.length > 3) {
            const more = document.createElement('span');
            more.className = 'skill-tag-more';
            more.textContent = `+${request.allSkills.length - 3} more`;
            skillsContainer.appendChild(more);
        }

        card.querySelector('.timeline-value').textContent = `${formatDate(request.startDate)} - ${formatDate(request.endDate)}`;
        card.querySelector('.duration-value').textContent = `${request.durationDays} days`;
        card.querySelector('.start-date-value').textContent = formatDate(request.startDate);
        card.querySelector('.end-date-value').textContent = formatDate(request.endDate);
    }

    populateRequestDetail(request) {
        document.getElementById('detailProjectName').textContent = request.projects?.name || 'N/A';
        document.getElementById('detailProjectDesc').textContent = request.projects?.description || 'N/A';
        
        const statusElem = document.getElementById('detailStatus');
        statusElem.textContent = formatStatus(request.status);
        statusElem.className = `request-status ${request.status}`;
        
        document.getElementById('detailSubmitted').textContent = formatDate(request.requested_at);
        
        const approvedRow = document.getElementById('detailApprovedRow');
        if (request.approved_at) {
            approvedRow.style.display = '';
            document.getElementById('detailApproved').textContent = formatDate(request.approved_at);
        } else {
            approvedRow.style.display = 'none';
        }
        
        document.getElementById('detailStartDate').textContent = formatDate(request.start_date);
        document.getElementById('detailEndDate').textContent = formatDate(request.end_date);
        document.getElementById('detailDuration').textContent = `${request.duration_days} days`;

        const tbody = document.getElementById('requirementsTableBody');
        tbody.innerHTML = '';
        request.requirements.forEach(req => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${req.quantity_needed || 1}</td>
                <td>${capitalize(req.experience_level || 'N/A')}</td>
                <td>${req.preferred_assignment_type || 'N/A'}</td>
                <td>
                    <div class="skills-tags">
                        ${(req.required_skills || []).map(skill => 
                            `<span class="skill-tag">${skill}</span>`
                        ).join('')}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });

        document.getElementById('detailNotes').textContent = request.notes || 'No additional notes';
    }
}

// ============================================
// RESOURCE REQUESTS APP
// ============================================

class ResourceRequestsApp {
    constructor() {
        this.dataService = new PMDataService();
        this.resourceRowManager = new ResourceRowManager();
        this.uiManager = new UIManager();
        this.allRequests = [];
    }

    async init() {
        try {
            ModalManager.showLoading();
            await this.dataService.initialize();
            this.resourceRowManager.init('resourceRowsContainer');
            this.setupEventListeners();
            await this.loadData();
            ModalManager.hideLoading();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[RESOURCE REQUESTS APP] Initialization error:', error);
            MessageManager.error('Failed to initialize. Please login again.');
            setTimeout(() => {
                window.location.href = "/login/HTML_Files/login.html";
            }, 2000);
        }
    }

    setupEventListeners() {
        document.getElementById('newRequestBtn')?.addEventListener('click', () => this.openNewRequestModal());
        document.getElementById('closeRequestModal')?.addEventListener('click', () => ModalManager.hide('newRequestModal'));
        document.getElementById('cancelFormBtn')?.addEventListener('click', () => ModalManager.hide('newRequestModal'));
        document.getElementById('addResourceBtn')?.addEventListener('click', () => this.resourceRowManager.addResourceRow());
        document.getElementById('requestForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.submitRequest();
        });
        document.getElementById('requestStatusFilter')?.addEventListener('change', () => this.filterRequests());
        
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn-view')) {
                const card = e.target.closest('.request-card');
                const requestId = card?.dataset.requestId;
                if (requestId) this.viewRequestDetails(requestId);
            }
        });
        
        document.getElementById('closeDetailModal')?.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        document.getElementById('closeDetailBtn')?.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        document.getElementById('logoutBtn')?.addEventListener('click', () => ModalManager.show('logoutModal'));
        document.getElementById('cancelLogout')?.addEventListener('click', () => ModalManager.hide('logoutModal'));
        document.getElementById('confirmLogout')?.addEventListener('click', () => this.handleLogout());

        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
    }

    async loadData() {
        try {
            ModalManager.showLoading();
            this.allRequests = await this.dataService.getMyRequests();
            const projects = await this.dataService.getMyProjects();
            this.populateProjectSelect(projects);
            this.renderRequests(this.allRequests);
            ModalManager.hideLoading();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[RESOURCE REQUESTS APP] Error loading data:', error);
            MessageManager.error('Failed to load data');
        }
    }

    populateProjectSelect(projects) {
        const projectSelect = document.getElementById('projectSelect');
        if (!projectSelect) return;

        projectSelect.innerHTML = '<option value="">Select a project</option>' + 
            projects.map(proj => `<option value="${proj.id}">${proj.name}</option>`).join('');
    }

    renderRequests(requests) {
        const container = document.getElementById('requestsList');
        const template = document.getElementById('requestCardTemplate');
        if (!container || !template) return;

        if (requests.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No Resource Requests</h3>
                    <p>Submit a new resource request to get started</p>
                </div>
            `;
            return;
        }

        container.innerHTML = '';

        requests.forEach(request => {
            const card = document.createElement('div');
            card.className = 'request-card';
            card.dataset.requestId = request.id;
            card.innerHTML = template.innerHTML;
            
            this.uiManager.populateRequestCard(card, request);
            
            container.appendChild(card);
        });
    }

    filterRequests() {
        const status = document.getElementById('requestStatusFilter')?.value;
        
        let filtered = this.allRequests;
        if (status === 'pending') {
            filtered = this.allRequests.filter(req => req.status === 'pending');
        } else if (status) {
            filtered = this.allRequests.filter(req => req.status === status);
        }
        
        this.renderRequests(filtered);
    }

    openNewRequestModal() {
        const form = document.getElementById('requestForm');
        if (form) form.reset();
        this.resourceRowManager.reset();
        ModalManager.show('newRequestModal');
    }

    async submitRequest() {
        const resources = this.resourceRowManager.getResourcesData();
        const formData = {
            project: document.getElementById('projectSelect')?.value,
            resources: resources
        };

        const errors = [];
        if (!formData.project) errors.push('Project is required');
        if (!formData.resources || formData.resources.length === 0) errors.push('At least one resource is required');
        
        formData.resources.forEach((resource, index) => {
            const resourceNum = index + 1;
            if (!resource.position) errors.push(`Resource ${resourceNum}: Position is required`);
            if (!resource.skills || resource.skills.length === 0) errors.push(`Resource ${resourceNum}: Skills are required`);
            if (!resource.startDate) errors.push(`Resource ${resourceNum}: Start date is required`);
            if (!resource.endDate) errors.push(`Resource ${resourceNum}: End date is required`);
            
            if (resource.startDate && resource.endDate) {
                if (new Date(resource.endDate) < new Date(resource.startDate)) {
                    errors.push(`Resource ${resourceNum}: End date must be after start date`);
                }
            }
        });
        
        if (errors.length > 0) {
            MessageManager.error(errors[0]);
            return;
        }

        try {
            ModalManager.hide('newRequestModal');
            ModalManager.showLoading();
            await this.dataService.submitRequest(formData);
            ModalManager.hideLoading();
            MessageManager.success('Resource request submitted successfully!');
            await this.loadData();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[RESOURCE REQUESTS APP] Error submitting request:', error);
            MessageManager.error('Failed to submit request: ' + error.message);
        }
    }

    async viewRequestDetails(requestId) {
        try {
            ModalManager.showLoading();
            const request = await this.dataService.getRequestDetails(requestId);
            this.uiManager.populateRequestDetail(request);
            ModalManager.hideLoading();
            ModalManager.show('requestDetailModal');
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[RESOURCE REQUESTS APP] Error loading request details:', error);
            MessageManager.error('Failed to load request details');
        }
    }

    async handleLogout() {
        localStorage.removeItem('loggedUser');
        sessionStorage.clear();
        ModalManager.hide('logoutModal');
        ModalManager.showLoading();
        setTimeout(() => {
            window.location.href = "/login/HTML_Files/login.html";
        }, 500);
    }
}

// ============================================
// INITIALIZATION
// ============================================

let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new ResourceRequestsApp();
    app.init();
});