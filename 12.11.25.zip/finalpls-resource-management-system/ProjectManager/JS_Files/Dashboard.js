// PROJECT MANAGER (PM) Dashboard.js - Enhanced Version with Supabase Integration
import { supabase } from "../../supabaseClient.js";

// ============================================
// MODAL UTILITIES
// ============================================

class ModalManager {
    static show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    static showLoading() {
        this.show('loadingOverlay');
    }

    static hideLoading() {
        this.hide('loadingOverlay');
    }
}

// ============================================
// MESSAGE UTILITIES
// ============================================

class MessageManager {
    static show(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        if (!container) return;

        const messageBox = document.createElement('div');
        messageBox.className = `message-box ${type}`;

        const iconMap = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const icon = document.createElement('i');
        icon.className = `fas ${iconMap[type]}`;

        const text = document.createElement('span');
        text.textContent = message;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'message-close';
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.addEventListener('click', () => messageBox.remove());

        messageBox.appendChild(icon);
        messageBox.appendChild(text);
        messageBox.appendChild(closeBtn);

        container.appendChild(messageBox);

        setTimeout(() => {
            messageBox.remove();
        }, 5000);
    }

    static success(message) {
        this.show(message, 'success');
    }

    static error(message) {
        this.show(message, 'error');
    }

    static warning(message) {
        this.show(message, 'warning');
    }

    static info(message) {
        this.show(message, 'info');
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatStatus(status) {
    const statusMap = {
        'active': 'Active',
        'ongoing': 'Ongoing',
        'planning': 'Planning',
        'completed': 'Completed',
        'on-hold': 'On Hold',
        'pending': 'Pending',
        'cancelled': 'Cancelled'
    };
    return statusMap[status] || status;
}

// ============================================
// PM DATA SERVICE - SUPABASE INTEGRATION
// ============================================

class PMDataService {
    constructor() {
        this.currentPMId = null;
        this.currentPMEmail = null;
    }

    async initialize() {
        // Get current logged in PM from localStorage or session
        const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
        
        if (loggedUser.email) {
            this.currentPMEmail = loggedUser.email;
            
            // Fetch PM user ID
            const { data: userData, error } = await supabase
                .from('users')
                .select('id, name, email')
                .eq('email', this.currentPMEmail)
                .eq('role', 'project_manager')
                .single();

            if (error) {
                console.error('[PM DATA SERVICE] Error fetching PM user:', error);
                throw error;
            }

            this.currentPMId = userData.id;
            console.log('[PM DATA SERVICE] Initialized for PM:', userData);
        } else {
            throw new Error('No logged in user found');
        }
    }

    async getDashboardStats() {
        try {
            console.log('[PM DATA SERVICE] Fetching dashboard stats for PM:', this.currentPMId);

            // Get active projects created by this PM
            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id, status')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;

            const activeProjects = projects?.length || 0;
            const projectIds = projects?.map(p => p.id) || [];

            // Get all team members assigned to PM's projects
            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select('user_id, assigned_hours')
                .in('project_id', projectIds)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            // Get unique team members
            const uniqueTeamMembers = [...new Set(assignments?.map(a => a.user_id) || [])];
            const teamMembers = uniqueTeamMembers.length;

            // Calculate total hours this week
            const today = new Date();
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Monday
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 4); // Friday

            const { data: worklogs, error: worklogError } = await supabase
                .from('worklogs')
                .select('hours')
                .in('project_id', projectIds)
                .gte('log_date', startOfWeek.toISOString().split('T')[0])
                .lte('log_date', endOfWeek.toISOString().split('T')[0]);

            if (worklogError) throw worklogError;

            const totalHours = worklogs?.reduce((sum, log) => sum + parseFloat(log.hours || 0), 0) || 0;

            // Calculate team utilization (total assigned hours / (team members * 40))
            const totalAssignedHours = assignments?.reduce((sum, a) => sum + parseInt(a.assigned_hours || 0), 0) || 0;
            const maxPossibleHours = teamMembers * 40;
            const teamUtilization = maxPossibleHours > 0 ? Math.round((totalAssignedHours / maxPossibleHours) * 100) : 0;

            console.log('[PM DATA SERVICE] Stats:', { activeProjects, teamMembers, totalHours, teamUtilization });

            return {
                activeProjects,
                teamMembers,
                totalHours: Math.round(totalHours),
                teamUtilization
            };
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching stats:', error);
            return {
                activeProjects: 0,
                teamMembers: 0,
                totalHours: 0,
                teamUtilization: 0
            };
        }
    }

    async getProjects() {
        try {
            console.log('[PM DATA SERVICE] Fetching projects for PM:', this.currentPMId);

            const { data: projects, error } = await supabase
                .from('projects')
                .select(`
                    id,
                    name,
                    description,
                    status,
                    priority,
                    start_date,
                    end_date,
                    duration_days
                `)
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active'])
                .order('created_at', { ascending: false });

            if (error) throw error;

            console.log('[PM DATA SERVICE] Projects fetched:', projects?.length || 0);
            return projects || [];
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching projects:', error);
            return [];
        }
    }

    async getTeamMembers() {
        try {
            console.log('[PM DATA SERVICE] Fetching team members for PM:', this.currentPMId);

            // Get all projects by this PM
            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;

            const projectIds = projects?.map(p => p.id) || [];

            // Get all team members assigned to these projects
            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select(`
                    user_id,
                    role_in_project,
                    users (
                        id,
                        name,
                        email,
                        user_details (
                            job_title,
                            status
                        )
                    )
                `)
                .in('project_id', projectIds)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            // Get unique team members
            const uniqueMembers = {};
            assignments?.forEach(assignment => {
                const user = assignment.users;
                if (user && !uniqueMembers[user.id]) {
                    uniqueMembers[user.id] = {
                        id: user.id,
                        name: user.name,
                        role: user.user_details?.[0]?.job_title || assignment.role_in_project || 'Team Member',
                        email: user.email,
                        status: user.user_details?.[0]?.status || 'Available',
                        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=4A90E2&color=fff`
                    };
                }
            });

            const teamMembers = Object.values(uniqueMembers);
            console.log('[PM DATA SERVICE] Team members fetched:', teamMembers.length);
            return teamMembers;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching team members:', error);
            return [];
        }
    }

    async getWeeklyAllocation(weekStart) {
        try {
            console.log('[PM DATA SERVICE] Fetching weekly allocation for week:', weekStart);

            // Get week date range
            const startDate = new Date(weekStart);
            const dates = [];
            for (let i = 0; i < 5; i++) { // Mon-Fri
                const date = new Date(startDate);
                date.setDate(startDate.getDate() + i);
                dates.push(date.toISOString().split('T')[0]);
            }

            // Get team members
            const teamMembers = await this.getTeamMembers();

            // Get projects
            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;

            const projectIds = projects?.map(p => p.id) || [];

            // Get worklogs for this week
            const { data: worklogs, error: worklogError } = await supabase
                .from('worklogs')
                .select('user_id, log_date, hours')
                .in('project_id', projectIds)
                .in('log_date', dates);

            if (worklogError) throw worklogError;

            // Process allocation data
            const allocation = teamMembers.map(member => {
                const memberLogs = worklogs?.filter(log => log.user_id === member.id) || [];
                
                const dailyHours = {
                    mon: 0, tue: 0, wed: 0, thu: 0, fri: 0
                };

                memberLogs.forEach(log => {
                    const logDate = new Date(log.log_date);
                    const dayIndex = (logDate.getDay() + 6) % 7; // Convert to Mon=0
                    const dayKeys = ['mon', 'tue', 'wed', 'thu', 'fri'];
                    if (dayIndex < 5) {
                        dailyHours[dayKeys[dayIndex]] += parseFloat(log.hours || 0);
                    }
                });

                return {
                    employee: member.name,
                    role: member.role,
                    avatar: member.avatar,
                    ...dailyHours
                };
            });

            console.log('[PM DATA SERVICE] Weekly allocation fetched:', allocation.length);
            return allocation;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching weekly allocation:', error);
            return [];
        }
    }

    async getAvailableTeamMembers() {
        try {
            console.log('[PM DATA SERVICE] Fetching available team members');

            const teamMembers = await this.getTeamMembers();

            // Get projects
            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;

            const projectIds = projects?.map(p => p.id) || [];

            // Get assignments to calculate utilization
            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select('user_id, assigned_hours')
                .in('project_id', projectIds)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            // Calculate utilization per member
            const userAssignedHours = {};
            assignments?.forEach(assignment => {
                if (!userAssignedHours[assignment.user_id]) {
                    userAssignedHours[assignment.user_id] = 0;
                }
                userAssignedHours[assignment.user_id] += parseInt(assignment.assigned_hours || 0);
            });

            // Filter and format available members (less than 40h)
            const availableMembers = teamMembers
                .map(member => {
                    const assignedHours = userAssignedHours[member.id] || 0;
                    const availableHours = 40 - assignedHours;
                    const utilization = Math.round((assignedHours / 40) * 100);

                    return {
                        ...member,
                        assignedHours,
                        availableHours,
                        utilization,
                        utilizationLevel: assignedHours >= 40 ? 'high' : assignedHours >= 20 ? 'medium' : 'low'
                    };
                })
                .filter(member => member.availableHours > 0)
                .sort((a, b) => b.availableHours - a.availableHours);

            console.log('[PM DATA SERVICE] Available team members:', availableMembers.length);
            return availableMembers;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching available team members:', error);
            return [];
        }
    }

    async saveHourAllocation(data) {
    try {
        console.log('[PM DATA SERVICE] Saving hour allocation:', data);

        // Get employee user_id
        const { data: userData, error: userError } = await supabase
            .from('users')
            .select('id')
            .eq('name', data.employee)
            .single();

        if (userError) throw userError;

        // Parse the date from the day string
        const weekSelect = document.getElementById('weekSelect');
        const weekStart = new Date(weekSelect.value);
        const dayMap = { 'Mon': 0, 'Tue': 1, 'Wed': 2, 'Thu': 3, 'Fri': 4 };
        const dayOffset = dayMap[data.day.split(',')[0]] || 0;
        const logDate = new Date(weekStart);
        logDate.setDate(weekStart.getDate() + dayOffset);

        const worklogData = {
            user_id: userData.id,
            project_id: parseInt(data.project.replace('proj', '')),
            log_date: logDate.toISOString().split('T')[0],
            hours: parseFloat(data.hours),
            work_description: data.task || 'Work assigned',
            work_type: 'assigned',
            status: 'in progress'
        };

        console.log('[PM DATA SERVICE] Worklog data to insert:', worklogData);
        console.log('[PM DATA SERVICE] Current PM ID:', this.currentPMId);
        console.log('[PM DATA SERVICE] Current PM Email:', this.currentPMEmail);

        // Insert worklog
        const { error: worklogError } = await supabase
            .from('worklogs')
            .insert(worklogData);

        if (worklogError) throw worklogError;

        console.log('[PM DATA SERVICE] Hour allocation saved successfully');
        return { success: true };
    } catch (error) {
        console.error('[PM DATA SERVICE] Error saving allocation:', error);
        throw error;
    }
}
}

// ============================================
// DASHBOARD APP
// ============================================

class DashboardApp {
    constructor() {
        this.dataService = new PMDataService();
        this.currentWeek = this.getCurrentWeekStart();
        this.selectedCell = null;
    }

    getCurrentWeekStart() {
        const today = new Date();
        const day = today.getDay();
        const diff = today.getDate() - day + (day === 0 ? -6 : 1);
        const monday = new Date(today.setDate(diff));
        return monday.toISOString().split('T')[0];
    }

    async init() {
        try {
            ModalManager.showLoading();
            
            // Initialize PM data service
            await this.dataService.initialize();
            
            this.setupEventListeners();
            await this.loadDashboard();
            
            ModalManager.hideLoading();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[DASHBOARD APP] Initialization error:', error);
            MessageManager.error('Failed to initialize dashboard. Please login again.');
            setTimeout(() => {
                window.location.href = "/login/HTML_Files/login.html";
            }, 2000);
        }
    }

    setupEventListeners() {
        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.openLogoutModal());
        }

        // Logout modal buttons
        const cancelLogout = document.getElementById('cancelLogout');
        const confirmLogout = document.getElementById('confirmLogout');
        
        if (cancelLogout) {
            cancelLogout.addEventListener('click', () => ModalManager.hide('logoutModal'));
        }
        if (confirmLogout) {
            confirmLogout.addEventListener('click', () => this.handleLogout());
        }

        // Week navigation
        const prevWeek = document.getElementById('prevWeek');
        const nextWeek = document.getElementById('nextWeek');
        const weekSelect = document.getElementById('weekSelect');

        if (prevWeek) {
            prevWeek.addEventListener('click', () => this.changeWeek(-1));
        }
        if (nextWeek) {
            nextWeek.addEventListener('click', () => this.changeWeek(1));
        }
        if (weekSelect) {
            weekSelect.addEventListener('change', (e) => {
                this.currentWeek = e.target.value;
                this.loadWeeklyAllocation();
            });
        }

        // Hour cell clicks
        document.addEventListener('click', (e) => {
            const cell = e.target.closest('.hours-cell');
            if (cell) {
                this.openAllocateModal(cell);
            }
        });

        // Allocate hours modal
        const closeAllocateModal = document.getElementById('closeAllocateModal');
        const cancelAllocate = document.getElementById('cancelAllocate');
        const allocateForm = document.getElementById('allocateHoursForm');

        if (closeAllocateModal) {
            closeAllocateModal.addEventListener('click', () => ModalManager.hide('allocateHoursModal'));
        }
        if (cancelAllocate) {
            cancelAllocate.addEventListener('click', () => ModalManager.hide('allocateHoursModal'));
        }
        if (allocateForm) {
            allocateForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveAllocation();
            });
        }

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
    }

    async loadDashboard() {
        try {
            // Load stats
            const stats = await this.dataService.getDashboardStats();
            this.updateStats(stats);

            // Load projects overview
            const projects = await this.dataService.getProjects();
            await this.loadProjectsDropdown(projects);

            // Load weekly allocation
            await this.loadWeeklyAllocation();

            // Load available team members
            await this.loadAvailableTeamMembers();

        } catch (error) {
            console.error('[DASHBOARD APP] Error loading dashboard:', error);
            MessageManager.error('Failed to load dashboard data');
        }
    }

    updateStats(stats) {
        const elements = {
            activeProjects: document.getElementById('activeProjects'),
            teamMembers: document.getElementById('teamMembers'),
            totalHours: document.getElementById('totalHours'),
            teamUtilization: document.getElementById('teamUtilization')
        };

        if (elements.activeProjects) elements.activeProjects.textContent = stats.activeProjects;
        if (elements.teamMembers) elements.teamMembers.textContent = stats.teamMembers;
        if (elements.totalHours) elements.totalHours.textContent = stats.totalHours + 'h';
        if (elements.teamUtilization) elements.teamUtilization.textContent = stats.teamUtilization + '%';
    }

    async loadProjectsDropdown(projects) {
        const projectSelect = document.getElementById('projectSelect');
        if (!projectSelect) return;

        projectSelect.innerHTML = '<option value="">Select Project</option>';
        
        projects.forEach(project => {
            const option = document.createElement('option');
            option.value = project.id;
            option.textContent = project.name;
            projectSelect.appendChild(option);
        });
    }

    async loadWeeklyAllocation() {
        try {
            const allocation = await this.dataService.getWeeklyAllocation(this.currentWeek);
            this.renderWeeklyAllocation(allocation);
        } catch (error) {
            console.error('[DASHBOARD APP] Error loading weekly allocation:', error);
            MessageManager.error('Failed to load weekly allocation');
        }
    }

    renderWeeklyAllocation(allocation) {
        const tbody = document.getElementById('allocationTableBody');
        if (!tbody) return;

        if (allocation.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: #6c757d;">
                        <i class="fas fa-users" style="font-size: 48px; opacity: 0.3; margin-bottom: 16px;"></i>
                        <p>No team members assigned yet</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = '';
        
        allocation.forEach(member => {
            const row = document.createElement('tr');
            
            const days = ['mon', 'tue', 'wed', 'thu', 'fri'];
            const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
            const totalHours = days.reduce((sum, day) => sum + (member[day] || 0), 0);
            
            row.innerHTML = `
                <td class="employee-cell">
                    <div class="employee-info">
                        <img src="${member.avatar}" alt="${member.employee}" class="employee-avatar-small">
                        <div>
                            <div class="employee-name">${member.employee}</div>
                            <div class="employee-role">${member.role}</div>
                        </div>
                    </div>
                </td>
                ${days.map((day, index) => {
                    const hours = member[day] || 0;
                    const cellClass = hours === 8 ? 'full' : hours > 0 ? 'partial' : 'empty';
                    return `
                        <td class="hours-cell ${cellClass}" data-employee="${member.employee}" data-day="${dayLabels[index]}">
                            <div class="hours-value">${hours}h</div>
                        </td>
                    `;
                }).join('')}
                <td class="total-cell">${totalHours}h</td>
            `;
            
            tbody.appendChild(row);
        });
    }

    async loadAvailableTeamMembers() {
        try {
            const availableMembers = await this.dataService.getAvailableTeamMembers();
            this.renderAvailableTeamMembers(availableMembers);
        } catch (error) {
            console.error('[DASHBOARD APP] Error loading available team members:', error);
        }
    }

    renderAvailableTeamMembers(members) {
        const container = document.querySelector('.available-grid');
        if (!container) return;

        if (members.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #6c757d;">
                    <i class="fas fa-users" style="font-size: 48px; opacity: 0.3; margin-bottom: 16px;"></i>
                    <p>All team members are fully allocated</p>
                </div>
            `;
            return;
        }

        container.innerHTML = '';
        
        members.forEach(member => {
            const card = document.createElement('div');
            card.className = 'available-card';
            
            card.innerHTML = `
                <img src="${member.avatar}" alt="${member.name}" class="available-avatar">
                <div class="available-info">
                    <h4>${member.name}</h4>
                    <p class="available-role">${member.role}</p>
                    <div class="utilization-badge ${member.utilizationLevel}">
                        <i class="fas fa-circle"></i> ${member.utilization}% Utilization
                    </div>
                    <p class="available-hours">${member.availableHours}h available</p>
                </div>
            `;
            
            container.appendChild(card);
        });
    }

    changeWeek(direction) {
        const weekSelect = document.getElementById('weekSelect');
        if (!weekSelect) return;

        const currentIndex = weekSelect.selectedIndex;
        const newIndex = currentIndex + direction;

        if (newIndex >= 0 && newIndex < weekSelect.options.length) {
            weekSelect.selectedIndex = newIndex;
            this.currentWeek = weekSelect.value;
            this.loadWeeklyAllocation();
        }
    }

    openAllocateModal(cell) {
        const employee = cell.dataset.employee;
        const day = cell.dataset.day;
        const currentHours = cell.querySelector('.hours-value').textContent;

        this.selectedCell = cell;

        document.getElementById('selectedEmployee').textContent = employee;
        document.getElementById('selectedDay').textContent = day;
        document.getElementById('hoursInput').value = parseInt(currentHours) || 0;

        ModalManager.show('allocateHoursModal');
    }

    async saveAllocation() {
        const project = document.getElementById('projectSelect').value;
        const hours = document.getElementById('hoursInput').value;
        const task = document.getElementById('taskInput').value;

        if (!project) {
            MessageManager.error('Please select a project');
            return;
        }

        if (hours < 0 || hours > 8) {
            MessageManager.error('Hours must be between 0 and 8');
            return;
        }

        try {
            ModalManager.hide('allocateHoursModal');
            ModalManager.showLoading();

            const data = {
                employee: document.getElementById('selectedEmployee').textContent,
                day: document.getElementById('selectedDay').textContent,
                project: project,
                hours: hours,
                task: task
            };

            await this.dataService.saveHourAllocation(data);

            // Reload the allocation table
            await this.loadWeeklyAllocation();
            await this.loadDashboard(); // Refresh stats

            ModalManager.hideLoading();
            MessageManager.success('Hours allocated successfully');
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[DASHBOARD APP] Error saving allocation:', error);
            MessageManager.error('Failed to save allocation');
        }
    }

    openLogoutModal() {
        ModalManager.show('logoutModal');
    }

    handleLogout() {
        localStorage.removeItem('loggedUser');
        sessionStorage.clear();
        ModalManager.hide('logoutModal');
        ModalManager.showLoading();
        
        setTimeout(() => {
            window.location.href = "/login/HTML_Files/login.html";
        }, 500);
    }
}

// ============================================
// INITIALIZATION
// ============================================

let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new DashboardApp();
    app.init();
});